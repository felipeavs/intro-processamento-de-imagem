% 2. Considere a matriz M = [10 2 10 5; 2 5 1 6; 2 4 8 10; 4 10 3 5]. Substitua os valores
% da primeira coluna e da �ltima linha por 1.

M = [10 2 10 5; 2 5 1 6; 2 4 8 10; 4 10 3 5]

M(:,1) = 1
M(end,:) = 1