img = imread('lennaCompress.png');
h = imhist(img);